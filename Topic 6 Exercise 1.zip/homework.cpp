// =============================================================================
// EXERCISE: operator overloading
// =============================================================================
//
// Goal: write a class `Polynomial` (integer coefficients) that can be used
// like a mathematical object:
//
//     Polynomial p = Polynomial({3, 2, 5});    // 3x^2 + 2x + 5
//     Polynomial q = Polynomial({1, 1});       // x + 1
//
// -----------------------------------------------------------------------------
// RULES
// -----------------------------------------------------------------------------
// 1. Write your class and all operators in the marked section below.
//
// 2. Storage format is your choice. You may store the coefficients highest-power-first
//    or lowest-power-first, in a std::vector, or anything else you like.
//
// 3. The constructor takes a list of integers ordered HIGHEST power first:
//        Polynomial{3, 2, 5}   means   3x^2 + 2x + 5
//        Polynomial{1, 0, -4}  means   x^2 - 4
//    Leading zeros are allowed in the input and must not change the meaning:
//        Polynomial{0, 0, 5, 2}  is the same polynomial as  Polynomial{5, 2}
//    An empty list or {0} gives the zero polynomial.
//
// 5. Two polynomials with the same mathematical value must always compare
//    equal, no matter how they were produced. (For example, subtracting
//    x^2 + 1 from x^2 + 3 must give exactly the same polynomial as {2}.)
//
// -----------------------------------------------------------------------------
// REQUIRED INTERFACE (your class must provide all of these)
// -----------------------------------------------------------------------------
//   Polynomial(vector<int> coeffs);   // highest power first
//   Polynomial + Polynomial
//   Polynomial - Polynomial
//   Polynomial + int
//   int + Polynomial
//   Polynomial - int
//   int - Polynomial
//   int operator()(int x) const    // evaluate the polynomial at x
//   std::ostream << Polynomial     // output format should look like e.g.: 2x^3 + 6x^2 + 4x + 10
//      use evaluate.py to check if what you made matches what is expected, adjust if needed.
//   Polynomial == Polynomial
//   Polynomial != Polynomial

#include <iostream>
#include <string>
#include <vector>

// ======================= YOUR CODE STARTS HERE ===============================



// ======================== YOUR CODE ENDS HERE ================================

int main(int argc, char* argv[]) {

    const char* defaultArgs[] = {"N/A", "3", "2", "5", "|", "1", "1"};
    if (argc == 1) {
        argc = 7;
        argv = const_cast<char**>(defaultArgs);
    }
    // by default, output should be:
    // "3x^2 + 2x + 5 ; 3x^2 + 3x + 6 ; 3x^2 + x + 4 ; 3x^2 + 2x + 8 ; 3x^2 + 2x + 8 ; 3x^2 + 2x + 2 ; -3x^2 - 2x - 2 ; 21 ; false ; true"

    std::vector<int> firstCoeffs, secondCoeffs;
    bool readingSecond = false;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "|")             readingSecond = true;
        else if (readingSecond)     secondCoeffs.push_back(std::stoi(arg));
        else                        firstCoeffs.push_back(std::stoi(arg));
    }

    Polynomial polynomial1(firstCoeffs);
    Polynomial polynomial2(secondCoeffs);
    const int number = 3;
    const int evalPoint = 2;

    std::cout << std::boolalpha
              << polynomial1                    << " ; "
              << polynomial1 + polynomial2      << " ; "
              << polynomial1 - polynomial2      << " ; "
              << polynomial1 + number           << " ; "
              << number      + polynomial1      << " ; "
              << polynomial1 - number           << " ; "
              << number      - polynomial1      << " ; "
              << polynomial1(evalPoint)         << " ; "
              << (polynomial1 == polynomial2)   << " ; "
              << (polynomial1 != polynomial2);
    return 0;
}